﻿namespace ArtificialLife
{
    public static class Const
    {
        public const uint SvgHeight = 300;
        public const int NumColumns = 250;
        public const uint FoodStart = 5000;
    }
}
